// LXP 동영상 진도 현황 - 백그라운드 서비스 워커
// 데이터 경로:
//   1) 로그인 세션으로 WS 토큰을 비밀번호 없이 발급 (admin/tool/mobile/launch.php → 커스텀스킴 리다이렉트)
//   2) 토큰으로 REST 호출: 진행중 과목 → 과목별 vod 목록 + 마감 + 완료여부
//   3) 토큰 실패 시 진단정보와 함께 에러 반환 (무한 로딩 방지)

const BASE = "https://lxp.kau.ac.kr";
const WS = BASE + "/webservice/rest/server.php";

// ---------- 툴바 클릭 → 패널 토글 ----------
chrome.action.onClicked.addListener(async (tab) => {
  if (tab && tab.url && tab.url.includes("lxp.kau.ac.kr")) {
    chrome.tabs.sendMessage(tab.id, { type: "togglePanel" }).catch(() => {});
  } else {
    chrome.tabs.create({ url: "https://lxp.kau.ac.kr/my/" });
  }
});

// ---------- 대시보드 ↔ 백그라운드 ----------
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.type === "collect") {
    collect(!!msg.forceToken)
      .then(sendResponse)
      .catch((e) => sendResponse({ error: String((e && e.message) || e), diag: ["예외: " + ((e && e.stack) || e)] }));
    return true; // 비동기 응답
  }
});

// ---------- fetch (타임아웃 포함) ----------
async function fetchT(url, opts = {}, ms = 20000) {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), ms);
  try {
    return await fetch(url, { credentials: "include", signal: ctl.signal, ...opts });
  } finally {
    clearTimeout(t);
  }
}

async function getText(path) {
  const r = await fetchT(BASE + path);
  return { finalUrl: r.url, status: r.status, text: await r.text() };
}

function looksLikeLogin(s) {
  return /\/login\/index\.php/.test(s.finalUrl) || /name="logintoken"|id="loginform"/.test(s.text);
}

// ---------- SW keepalive (토큰 대기 중 종료 방지) ----------
let keepAliveTimer = null;
function keepAlive(on) {
  if (on && !keepAliveTimer) {
    keepAliveTimer = setInterval(() => chrome.runtime.getPlatformInfo(() => {}), 20000);
  } else if (!on && keepAliveTimer) {
    clearInterval(keepAliveTimer);
    keepAliveTimer = null;
  }
}

// ---------- WS 토큰 (비밀번호 불필요) ----------
// launch.php 는 urlscheme 파라미터를 무시하고 항상 moodlemobile://token=<base64> 로 302.
// base64 디코드하면 "passporthash:::token[:::privatetoken]".
function acquireToken(diag) {
  return new Promise((resolve, reject) => {
    const launchUrl =
      `${BASE}/admin/tool/mobile/launch.php?service=moodle_mobile_app` +
      `&passport=${Math.random()}&urlscheme=moodlemobile`;
    let done = false;
    let navTabId = null;

    const finish = (fn, arg) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      chrome.webRequest.onHeadersReceived.removeListener(onHdrs);
      chrome.webRequest.onBeforeRedirect.removeListener(onRedirect);
      if (navTabId != null) chrome.tabs.remove(navTabId).catch(() => {});
      keepAlive(false);
      fn(arg);
    };

    const timer = setTimeout(
      () => finish(reject, new Error("토큰 리다이렉트 시간초과(15s) — webRequest 미발화")),
      15000
    );

    const grab = (url, src) => {
      const m = (url || "").match(/token=([A-Za-z0-9%_\-+/=]+)/);
      if (!m || /^https?:/i.test(url)) return false;
      diag && diag.push("토큰 리다이렉트 포착(" + src + ")");
      try {
        const decoded = atob(decodeURIComponent(m[1].replace(/ /g, "+")));
        const parts = decoded.split(":::");
        finish(resolve, parts.length >= 2 ? parts[1] : decoded);
      } catch (e) {
        finish(reject, new Error("토큰 디코드 실패: " + e.message));
      }
      return true;
    };

    function onHdrs(d) {
      const loc = (d.responseHeaders || []).find((h) => h.name.toLowerCase() === "location");
      if (loc) grab(loc.value, "headers");
    }
    function onRedirect(d) { grab(d.redirectUrl, "redirect"); }

    keepAlive(true);
    const filter = { urls: ["*://lxp.kau.ac.kr/admin/tool/mobile/launch.php*"] };
    chrome.webRequest.onHeadersReceived.addListener(onHdrs, filter, ["responseHeaders"]);
    chrome.webRequest.onBeforeRedirect.addListener(onRedirect, filter);
    // 실제 백그라운드 탭 내비게이션 → webRequest 확실히 발화. 포착 즉시 탭 제거.
    chrome.tabs.create({ url: launchUrl, active: false }, (tab) => {
      if (chrome.runtime.lastError || !tab) {
        finish(reject, new Error("launch 탭 생성 실패: " + (chrome.runtime.lastError?.message || "?")));
      } else {
        navTabId = tab.id;
      }
    });
  });
}

async function getToken(force, diag) {
  if (!force) {
    const c = await chrome.storage.local.get("wstoken");
    if (c.wstoken) { diag && diag.push("캐시된 토큰 사용"); return c.wstoken; }
  }
  const token = await acquireToken(diag);
  await chrome.storage.local.set({ wstoken: token });
  return token;
}

async function wsCall(token, wsfunction, params = {}) {
  const body = new URLSearchParams({ wstoken: token, wsfunction, moodlewsrestformat: "json", ...params });
  const r = await fetchT(WS, { method: "POST", body });
  const j = await r.json();
  if (j && j.exception) {
    const err = new Error(j.errorcode || j.message || "ws error");
    err.errorcode = j.errorcode;
    throw err;
  }
  return j;
}

// ---------- 메인 ----------
async function collect(forceToken) {
  const diag = [];

  const home = await getText("/my/").catch((e) => ({ error: e }));
  if (home.error) return { error: "HOME_FETCH_FAIL", diag: ["/my/ 접속 실패: " + home.error.message] };
  if (looksLikeLogin(home)) return { error: "NOT_LOGGED_IN", diag };

  let token = null;
  try {
    token = await getToken(forceToken, diag);
    diag.push("WS 토큰 확보 OK (" + String(token).slice(0, 6) + "…)");
  } catch (e) {
    diag.push("WS 토큰 실패: " + e.message);
    return { error: "TOKEN_FAIL", diag };
  }

  try {
    const data = await collectViaWS(token, diag);
    return { ok: true, mode: "ws", diag, fetchedAt: Date.now(), ...data };
  } catch (e) {
    diag.push("WS 수집 실패: " + (e.errorcode || e.message));
    if (e.errorcode === "invalidtoken") {
      await chrome.storage.local.remove("wstoken");
      try {
        const token2 = await getToken(true, diag);
        const data = await collectViaWS(token2, diag);
        return { ok: true, mode: "ws", diag, fetchedAt: Date.now(), ...data };
      } catch (e2) {
        diag.push("재발급 후에도 실패: " + (e2.errorcode || e2.message));
      }
    }
    return { error: "WS_FAIL", diag };
  }
}

async function collectViaWS(token, diag) {
  const site = await wsCall(token, "core_webservice_get_site_info");
  const courses = await wsCall(token, "core_enrol_get_users_courses", { userid: String(site.userid) });
  const now = Math.floor(Date.now() / 1000);
  const WEEK = 7 * 86400;

  let current = courses.filter(
    (c) => c.enddate && c.enddate > now && (!c.startdate || c.startdate <= now + WEEK)
  );
  if (!current.length) {
    const terms = courses
      .map((c) => (String(c.shortname).match(/\((\d{4}-\d{2}),/) || [])[1])
      .filter(Boolean)
      .sort();
    const latest = terms[terms.length - 1];
    current = latest ? courses.filter((c) => String(c.shortname).includes(`(${latest},`)) : courses;
  }
  diag.push(`과목 ${courses.length}개 중 진행중 ${current.length}개`);

  const items = [];
  for (const c of current) {
    let sections;
    try {
      sections = await wsCall(token, "core_course_get_contents", { courseid: String(c.id) });
    } catch (e) {
      diag.push(`${c.shortname || c.id} contents 실패: ${e.errorcode || e.message}`);
      continue;
    }
    const cname = String(c.fullname || c.shortname).replace(/\s*\(\d{3,4}\)\s*$/, "").trim();
    for (const sec of sections) {
      for (const m of sec.modules || []) {
        if (m.modname !== "vod") continue;
        const dates = m.dates || [];
        const pick = (id) => (dates.find((d) => d.dataid === id) || {}).timestamp || null;
        const cd = m.completiondata || {};
        const done = cd.state === 1 || cd.state === 2;
        items.push({
          id: String(m.id),
          course: cname,
          week: sec.name || "",
          title: m.name || "",
          url: m.url || `${BASE}/mod/vod/view.php?id=${m.id}`,
          open: pick("timeopen"),
          deadline: pick("timeclose") || pick("timelateness") || null,
          percent: cd.hascompletion ? (done ? 100 : 0) : null,
          exact: false,
          completed: !!done,
        });
      }
    }
  }
  diag.push(`동영상 ${items.length}개 수집`);
  return { items };
}
