// LXP 동영상 진도 현황 - 우측 사이드 패널 (LXP 페이지에 오버레이)
(() => {
  if (window.__lxpProgressPanel) return;
  window.__lxpProgressPanel = true;

  const DOW = ["일", "월", "화", "수", "목", "금", "토"];
  const HOST_ID = "lxp-progress-panel-host";
  let host, root, panel, lastItems = null, hiddenIds = new Set();

  const CSS = `
  :host { all: initial; }
  * { box-sizing: border-box; font-family: "Pretendard", -apple-system, "Segoe UI", "Malgun Gothic", sans-serif; }
  .wrap {
    position: fixed; top: 0; right: 0; width: 360px; height: 100vh; z-index: 2147483647;
    background: #f7f8fa; border-left: 1px solid #e2e4e8; box-shadow: -6px 0 24px rgba(16,24,40,.08);
    display: flex; flex-direction: column; transform: translateX(0); transition: transform .22s ease;
    color: #1c1f23;
  }
  .wrap.hidden { transform: translateX(378px); }
  .head {
    display: flex; align-items: center; gap: 8px; padding: 14px 14px 12px; border-bottom: 1px solid #e6e8ec;
    background: #fff;
  }
  .head h1 { margin: 0; font-size: 14px; font-weight: 700; flex: 1; letter-spacing: -.01em; }
  .head .sub { font-size: 11px; color: #6b7280; font-weight: 500; margin-top: 2px; }
  .iconbtn {
    border: none; background: transparent; cursor: pointer; color: #6b7280; font-size: 13px;
    padding: 5px 7px; border-radius: 7px; line-height: 1;
  }
  .iconbtn:hover { background: #f0f1f3; color: #1c1f23; }
  .toolbar {
    display: flex; align-items: center; gap: 10px; padding: 8px 14px; font-size: 12px; color: #6b7280;
    border-bottom: 1px solid #eef0f2; background: #fff;
  }
  .toolbar label { display: flex; align-items: center; gap: 5px; cursor: pointer; user-select: none; }
  .count { margin-left: auto; }
  .count b { color: #1c1f23; }
  .body { flex: 1; overflow-y: auto; padding: 10px; display: flex; flex-direction: column; gap: 8px; }
  .card {
    background: #fff; border: 1px solid #e6e8ec; border-radius: 11px; padding: 11px 12px;
    position: relative;
  }
  .card.done { opacity: .55; }
  .row1 { display: flex; align-items: baseline; gap: 6px; padding-right: 18px; }
  .course { font-size: 12px; font-weight: 700; }
  .week { font-size: 11.5px; color: #6b7280; }
  .x {
    position: absolute; top: 7px; right: 7px; border: none; background: transparent; cursor: pointer;
    color: #b8bcc4; font-size: 13px; line-height: 1; padding: 3px 5px; border-radius: 6px;
  }
  .x:hover { background: #fdecec; color: #e5484d; }
  .title { font-size: 13.5px; font-weight: 600; margin: 6px 0 8px; letter-spacing: -.01em; }
  .title a { color: inherit; text-decoration: none; }
  .title a:hover { text-decoration: underline; }
  .row3 { display: flex; align-items: center; gap: 8px; }
  .pill { font-size: 11px; font-weight: 700; padding: 2px 8px; border-radius: 999px; white-space: nowrap; }
  .pill.todo { background: #fdecec; color: #e5484d; }
  .pill.done { background: #e7f6ee; color: #1faa5f; }
  .dday { font-size: 11px; font-weight: 700; padding: 2px 7px; border-radius: 999px; background: #eceef1; color: #6b7280; white-space: nowrap; }
  .dday.d-danger { background: #fdecec; color: #e5484d; }
  .dday.d-warn { background: #fbf1e0; color: #b9791f; }
  .dday.d-over { background: #4b1113; color: #ffd9da; }
  .deadline { font-size: 11px; color: #8b909a; margin-left: auto; }
  .msg { padding: 40px 20px; text-align: center; color: #6b7280; font-size: 12.5px; line-height: 1.7; }
  .msg .big { font-size: 13px; color: #1c1f23; font-weight: 600; margin-bottom: 5px; }
  .foot {
    padding: 9px 14px; font-size: 11px; color: #8b909a; border-top: 1px solid #eef0f2; background: #fff;
    display: flex; gap: 10px; align-items: center;
  }
  .foot a { color: #2f6fed; cursor: pointer; text-decoration: none; }
  .foot a:hover { text-decoration: underline; }
  details.diag { font-size: 10.5px; color: #9aa0a8; padding: 6px 14px; background: #fff; border-top: 1px solid #eef0f2; }
  details.diag pre { white-space: pre-wrap; margin: 6px 0 0; }
  .handle {
    position: fixed; top: 50%; right: 0; transform: translateY(-50%); z-index: 2147483646;
    background: #2f6fed; color: #fff; border: none; cursor: pointer; writing-mode: vertical-rl;
    padding: 12px 6px; border-radius: 8px 0 0 8px; font-size: 11px; font-weight: 700; letter-spacing: .05em;
    box-shadow: -2px 0 10px rgba(16,24,40,.15); display: none;
  }
  .handle.show { display: block; }
  `;

  function build() {
    host = document.createElement("div");
    host.id = HOST_ID;
    root = host.attachShadow({ mode: "open" });
    const style = document.createElement("style");
    style.textContent = CSS;
    root.appendChild(style);

    panel = document.createElement("div");
    panel.className = "wrap hidden";
    panel.innerHTML = `
      <div class="head">
        <div style="flex:1">
          <h1>동영상 진도 현황</h1>
          <div class="sub" id="sub">불러오는 중…</div>
        </div>
        <button class="iconbtn" id="refresh" title="새로고침">↻</button>
        <button class="iconbtn" id="close" title="닫기">✕</button>
      </div>
      <div class="toolbar">
        <label><input type="checkbox" id="showDone"> 완료 포함</label>
        <span class="count" id="count"></span>
      </div>
      <div class="body" id="body"></div>
      <div class="foot" id="foot" hidden></div>
      <details class="diag" id="diagWrap" hidden><summary>진단 정보</summary><pre id="diag"></pre></details>
    `;
    root.appendChild(panel);

    const handle = document.createElement("button");
    handle.className = "handle";
    handle.textContent = "진도현황";
    handle.addEventListener("click", () => toggle(true));
    root.appendChild(handle);
    panel._handle = handle;

    root.getElementById("close").addEventListener("click", () => toggle(false));
    root.getElementById("refresh").addEventListener("click", () => load(true));
    root.getElementById("showDone").addEventListener("change", (e) => {
      chrome.storage.local.set({ showDone: e.target.checked });
      if (lastItems) render(lastItems);
    });

    document.documentElement.appendChild(host);
  }

  function toggle(show) {
    const open = show ?? panel.classList.contains("hidden");
    panel.classList.toggle("hidden", !open);
    panel._handle.classList.toggle("show", !open);
    if (open && !lastItems) load(false);
  }

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.type === "togglePanel") toggle();
  });

  async function load(force) {
    const sub = root.getElementById("sub");
    sub.textContent = force ? "새로고침 중…" : "불러오는 중…";
    root.getElementById("body").innerHTML = "";
    try {
      const st = await chrome.storage.local.get(["showDone", "hiddenIds"]);
      root.getElementById("showDone").checked = !!st.showDone;
      hiddenIds = new Set(st.hiddenIds || []);

      const data = await Promise.race([
        chrome.runtime.sendMessage({ type: "collect", forceToken: force }),
        new Promise((_, r) => setTimeout(() => r(new Error("__timeout__")), 90000)),
      ]);
      showDiag(data && data.diag, data && data.mode);
      if (!data || data.error) {
        message(errText(data && data.error));
        return;
      }
      lastItems = data.items || [];
      render(lastItems, data.fetchedAt);
    } catch (e) {
      message([e.message === "__timeout__" ? "응답이 없습니다." : "불러오지 못했습니다.",
        e.message === "__timeout__" ? "확장을 새로고침하거나 다시 시도하세요." : String(e.message || e)]);
    }
  }

  const ERR = {
    NOT_LOGGED_IN: ["LXP에 로그인되어 있지 않습니다.", "로그인 후 새로고침하세요."],
    HOME_FETCH_FAIL: ["LXP에 연결하지 못했습니다.", "네트워크를 확인하세요."],
    TOKEN_FAIL: ["학습 데이터 접근 권한을 얻지 못했습니다.", "로그인 상태를 확인하고 새로고침하세요."],
    WS_FAIL: ["학습 데이터를 불러오지 못했습니다.", "잠시 후 새로고침하세요."],
  };
  const errText = (c) => ERR[c] || ["오류가 발생했습니다.", String(c || "")];

  function showDiag(lines, mode) {
    const w = root.getElementById("diagWrap");
    if (!lines || !lines.length) { w.hidden = true; return; }
    root.getElementById("diag").textContent = lines.concat("모드: " + mode).join("\n");
    w.hidden = false;
  }

  function message(m) {
    root.getElementById("count").textContent = "";
    root.getElementById("foot").hidden = true;
    root.getElementById("body").innerHTML =
      `<div class="msg"><div class="big">${esc(m[0])}</div>${esc(m[1] || "")}</div>`;
    root.getElementById("sub").textContent = "";
  }

  function render(items, fetchedAt) {
    const showDone = root.getElementById("showDone").checked;
    const now = Date.now();
    const norm = items
      .filter((it) => !hiddenIds.has(String(it.id)))
      .map((it) => {
        let dl = it.deadline || null;
        if (dl && dl < 1e12) dl *= 1000;
        return {
          id: String(it.id), course: it.course || "", week: cleanWeek(it.week),
          title: it.title || "(제목 없음)", url: it.url || null,
          deadline: dl, dday: dl != null ? Math.ceil((dl - now) / 86400000) : null,
          completed: !!it.completed,
        };
      });

    const pending = norm.filter((x) => !x.completed).sort(byDeadline);
    const done = norm.filter((x) => x.completed).sort(byDeadline);
    const hiddenCount = items.length - norm.length;

    root.getElementById("count").innerHTML =
      `미완료 <b>${pending.length}</b> · 완료 <b>${done.length}</b>`;

    const body = root.getElementById("body");
    body.innerHTML = "";
    if (!pending.length && !(showDone && done.length)) {
      body.innerHTML = `<div class="msg"><div class="big">${
        norm.length ? "모든 동영상을 다 봤어요 🎉" : "표시할 동영상이 없습니다."
      }</div>${norm.length ? "완료 항목은 '완료 포함' 으로 볼 수 있어요." : ""}</div>`;
    } else {
      for (const it of pending) body.appendChild(card(it));
      if (showDone) for (const it of done) body.appendChild(card(it));
    }

    const foot = root.getElementById("foot");
    if (hiddenCount > 0) {
      foot.hidden = false;
      foot.innerHTML = `숨긴 항목 ${hiddenCount}개 <a id="unhide">모두 표시</a>`;
      root.getElementById("unhide").addEventListener("click", async () => {
        hiddenIds = new Set();
        await chrome.storage.local.set({ hiddenIds: [] });
        render(lastItems, fetchedAt);
      });
    } else {
      foot.hidden = true;
    }

    const w = new Date(fetchedAt || Date.now());
    root.getElementById("sub").textContent =
      `${w.getMonth() + 1}/${w.getDate()} ${String(w.getHours()).padStart(2, "0")}:${String(w.getMinutes()).padStart(2, "0")} 기준`;
  }

  const byDeadline = (a, b) =>
    a.deadline == null && b.deadline == null ? 0 :
    a.deadline == null ? 1 : b.deadline == null ? -1 : a.deadline - b.deadline;

  function cleanWeek(w) {
    if (!w) return "";
    w = String(w).replace(/\s+/g, " ").trim();
    const m = w.match(/(\d+)\s*주/);
    return m ? m[1] + "주차" : /^\d+$/.test(w) ? w + "주차" : w;
  }

  function ddayEl(dday, completed) {
    const s = document.createElement("span");
    s.className = "dday";
    if (completed) return (s.remove(), null);
    if (dday == null) { s.textContent = "상시"; return s; }
    if (dday < 0) { s.textContent = `${-dday}일 지남`; s.classList.add("d-over"); return s; }
    if (dday === 0) { s.textContent = "오늘 마감"; s.classList.add("d-danger"); return s; }
    s.textContent = "D-" + dday;
    if (dday <= 2) s.classList.add("d-danger");
    else if (dday <= 5) s.classList.add("d-warn");
    return s;
  }

  function fmtDeadline(ts) {
    if (ts == null) return "상시 수강";
    const d = new Date(ts);
    return `${d.getMonth() + 1}/${d.getDate()}(${DOW[d.getDay()]}) ${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
  }

  function card(it) {
    const el = document.createElement("div");
    el.className = "card" + (it.completed ? " done" : "");

    const r1 = document.createElement("div");
    r1.className = "row1";
    r1.innerHTML = `<span class="course">${esc(it.course)}</span>` +
      (it.week ? `<span class="week">· ${esc(it.week)}</span>` : "");
    el.appendChild(r1);

    const x = document.createElement("button");
    x.className = "x"; x.textContent = "✕"; x.title = "목록에서 숨기기";
    x.addEventListener("click", async () => {
      hiddenIds.add(it.id);
      await chrome.storage.local.set({ hiddenIds: [...hiddenIds] });
      render(lastItems);
    });
    el.appendChild(x);

    const t = document.createElement("div");
    t.className = "title";
    t.innerHTML = it.url ? `<a href="${esc(it.url)}" target="_blank" rel="noreferrer">${esc(it.title)}</a>` : esc(it.title);
    el.appendChild(t);

    const r3 = document.createElement("div");
    r3.className = "row3";
    const pill = document.createElement("span");
    pill.className = "pill " + (it.completed ? "done" : "todo");
    pill.textContent = it.completed ? "완료" : "미완료";
    r3.appendChild(pill);
    const dd = ddayEl(it.dday, it.completed);
    if (dd) r3.appendChild(dd);
    const dl = document.createElement("span");
    dl.className = "deadline";
    dl.textContent = fmtDeadline(it.deadline);
    r3.appendChild(dl);
    el.appendChild(r3);

    return el;
  }

  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  build();
})();
